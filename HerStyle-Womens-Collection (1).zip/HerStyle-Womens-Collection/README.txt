HERSTYLE - WOMEN'S FASHION COLLECTION
=====================================

A demonstration e-commerce website built with Python, Flask, HTML5 and CSS3.
It uses Python dictionaries/lists for products and Flask sessions for the cart.
There is no database and no JavaScript.

PROJECT FILES
-------------
app.py                 Flask routes, sample catalogue and session cart
requirements.txt       Python dependency
templates/             HTML templates with internal CSS
  home.html             Homepage, search, category filter and product cards
  product.html          Product details
  cart.html             Cart, quantity update and remove
  checkout.html         Demo checkout form
  success.html          Demo order confirmation
  not_found.html        Friendly 404 page

RUN IN VS CODE (WINDOWS)
------------------------
1. Extract the ZIP file.
2. Open the HerStyle-Womens-Collection folder in VS Code.
3. Open Terminal > New Terminal.
4. Optional: create a virtual environment:
      py -m venv .venv
      .venv\Scripts\Activate.ps1
5. Install requirements:
      py -m pip install -r requirements.txt
6. Start the website:
      py app.py
7. Open this URL in your browser:
      http://127.0.0.1:5000

STOP SERVER
-----------
Press Ctrl + C in the VS Code terminal.

NOTES
-----
- Product images are loaded from external Unsplash image URLs, so an internet
  connection is required to display them.
- Product and cart data are sample/demo data. The cart is stored in the Flask
  session cookie. Orders are only shown as a demo confirmation.
- No real payment, inventory, delivery, or permanent order storage is provided.
- For deployment, set a strong SECRET_KEY environment variable and use a
  production WSGI server. Do not use Flask debug mode in production.
