from flask import Flask, render_template, request, redirect, url_for, session, flash
from datetime import datetime
import os

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "herstyle-demo-secret-key-change-me")

# Demo catalogue stored in Python dictionaries (no database).
PRODUCTS = [
    {"id": 1, "name": "Blush Floral Baby Frock", "category": "Baby & Kids", "price": 699,
     "sizes": ["0-6M", "6-12M", "1-2Y"], "colors": ["Blush Pink", "Ivory"],
     "image": "https://images.unsplash.com/photo-1519238263530-99bdd11df2ea?w=900&auto=format&fit=crop&q=85",
     "description": "A soft, occasion-ready frock with a pretty floral finish for little celebrations.", "tag": "New"},
    {"id": 2, "name": "Girls Festive Pavadai Set", "category": "Baby & Kids", "price": 1199,
     "sizes": ["2-3Y", "4-5Y", "6-7Y"], "colors": ["Rose", "Lavender"],
     "image": "https://images.unsplash.com/photo-1596870230751-ebdfce98ec42?w=900&auto=format&fit=crop&q=85",
     "description": "A festive traditional set designed for family functions and special occasions.", "tag": "Popular"},
    {"id": 3, "name": "Classic Cotton Saree", "category": "Traditional Wear", "price": 1499,
     "sizes": ["Free Size"], "colors": ["Dusty Rose", "Teal"],
     "image": "https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=900&auto=format&fit=crop&q=85",
     "description": "An easy-to-drape cotton saree with a timeless everyday elegance.", "tag": "Bestseller"},
    {"id": 4, "name": "Royal Silk Wedding Saree", "category": "Traditional Wear", "price": 4299,
     "sizes": ["Free Size"], "colors": ["Magenta", "Wine"],
     "image": "https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?w=900&auto=format&fit=crop&q=85",
     "description": "A statement silk-look saree for weddings, receptions and treasured occasions.", "tag": "Premium"},
    {"id": 5, "name": "Lavender Anarkali Suit", "category": "Ethnic Wear", "price": 1899,
     "sizes": ["S", "M", "L", "XL"], "colors": ["Lavender", "Peach"],
     "image": "https://images.unsplash.com/photo-1583391733956-6c78276477e5?w=900&auto=format&fit=crop&q=85",
     "description": "A graceful flowing Anarkali silhouette for festive days and evening events.", "tag": "New"},
    {"id": 6, "name": "Everyday Chudi Set", "category": "Ethnic Wear", "price": 999,
     "sizes": ["S", "M", "L", "XL", "XXL"], "colors": ["Pink", "Blue"],
     "image": "https://images.unsplash.com/photo-1597983073493-88cd35cf93e4?w=900&auto=format&fit=crop&q=85",
     "description": "A comfortable coordinated set made for everyday style and easy movement.", "tag": "Popular"},
    {"id": 7, "name": "Rose Garden Midi Dress", "category": "Western Wear", "price": 1299,
     "sizes": ["XS", "S", "M", "L", "XL"], "colors": ["Rose", "Black"],
     "image": "https://images.unsplash.com/photo-1539008835657-9e8e9680c956?w=900&auto=format&fit=crop&q=85",
     "description": "A versatile midi dress that moves effortlessly from brunch to a dinner date.", "tag": "Bestseller"},
    {"id": 8, "name": "Elegant Evening Maxi Gown", "category": "Western Wear", "price": 2499,
     "sizes": ["S", "M", "L", "XL"], "colors": ["Plum", "Emerald"],
     "image": "https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=900&auto=format&fit=crop&q=85",
     "description": "A polished floor-length gown for celebrations, parties and memorable evenings.", "tag": "Premium"},
    {"id": 9, "name": "Everyday Rose Kurti", "category": "Kurtis", "price": 799,
     "sizes": ["S", "M", "L", "XL", "XXL"], "colors": ["Rose", "Mustard"],
     "image": "https://images.unsplash.com/photo-1585487000160-6ebcfceb0d03?w=900&auto=format&fit=crop&q=85",
     "description": "A versatile kurti with an easy fit for workdays, errands and casual outings.", "tag": "New"},
    {"id": 10, "name": "Soft Cotton Nightwear Set", "category": "Nightwear", "price": 899,
     "sizes": ["M", "L", "XL", "XXL"], "colors": ["Lilac", "Peach"],
     "image": "https://images.unsplash.com/photo-1618354691373-d851c5c3a990?w=900&auto=format&fit=crop&q=85",
     "description": "A relaxed, breathable nightwear set for comfortable evenings at home.", "tag": "Comfort"},
    {"id": 11, "name": "Maternity Comfort Dress", "category": "Maternity & Plus Size", "price": 1399,
     "sizes": ["L", "XL", "XXL", "3XL"], "colors": ["Mauve", "Navy"],
     "image": "https://images.unsplash.com/photo-1525507119028-ed4c629a60a3?w=900&auto=format&fit=crop&q=85",
     "description": "A roomy, comfort-first dress designed for relaxed everyday wear.", "tag": "Comfort"},
    {"id": 12, "name": "Festive Dupatta Set", "category": "Festive & Accessories", "price": 1099,
     "sizes": ["S", "M", "L", "XL"], "colors": ["Fuchsia", "Ivory"],
     "image": "https://images.unsplash.com/photo-1603217192097-13c306522271?w=900&auto=format&fit=crop&q=85",
     "description": "A festive outfit set with a statement dupatta for celebrations and gatherings.", "tag": "Limited"}
]

CATEGORIES = [
    "Baby & Kids", "Traditional Wear", "Ethnic Wear", "Western Wear",
    "Kurtis", "Nightwear", "Maternity & Plus Size", "Festive & Accessories"
]

def cart_items():
    cart = session.get("cart", {})
    items = []
    for product_id, quantity in cart.items():
        product = next((p for p in PRODUCTS if p["id"] == int(product_id)), None)
        if product and int(quantity) > 0:
            item = dict(product)
            item["quantity"] = int(quantity)
            item["subtotal"] = item["price"] * item["quantity"]
            items.append(item)
    return items

@app.context_processor
def inject_cart_count():
    return {"cart_count": sum(int(q) for q in session.get("cart", {}).values())}

@app.route("/")
def home():
    query = request.args.get("q", "").strip()
    category = request.args.get("category", "").strip()
    products = PRODUCTS
    if query:
        products = [p for p in products if query.casefold() in p["name"].casefold()
                    or query.casefold() in p["category"].casefold()]
    if category and category in CATEGORIES:
        products = [p for p in products if p["category"] == category]
    return render_template("home.html", products=products, categories=CATEGORIES,
                           query=query, selected_category=category, all_products=PRODUCTS)

@app.route("/product/<int:product_id>")
def product_detail(product_id):
    product = next((p for p in PRODUCTS if p["id"] == product_id), None)
    if not product:
        return render_template("not_found.html"), 404
    return render_template("product.html", product=product)

@app.route("/add-to-cart/<int:product_id>", methods=["POST"])
def add_to_cart(product_id):
    product = next((p for p in PRODUCTS if p["id"] == product_id), None)
    if not product:
        return render_template("not_found.html"), 404
    cart = session.get("cart", {})
    key = str(product_id)
    try:
        quantity = max(1, min(int(request.form.get("quantity", 1)), 20))
    except ValueError:
        quantity = 1
    cart[key] = int(cart.get(key, 0)) + quantity
    session["cart"] = cart
    flash(f"{product['name']} added to your bag.", "success")
    return redirect(request.referrer or url_for("home"))

@app.route("/cart")
def cart():
    items = cart_items()
    total = sum(item["subtotal"] for item in items)
    return render_template("cart.html", items=items, total=total)

@app.route("/update-cart/<int:product_id>", methods=["POST"])
def update_cart(product_id):
    cart = session.get("cart", {})
    key = str(product_id)
    if key in cart:
        try:
            quantity = int(request.form.get("quantity", 1))
        except ValueError:
            quantity = 1
        if quantity <= 0:
            cart.pop(key, None)
        else:
            cart[key] = min(quantity, 20)
        session["cart"] = cart
    return redirect(url_for("cart"))

@app.route("/remove-from-cart/<int:product_id>", methods=["POST"])
def remove_from_cart(product_id):
    cart = session.get("cart", {})
    cart.pop(str(product_id), None)
    session["cart"] = cart
    return redirect(url_for("cart"))

@app.route("/checkout", methods=["GET", "POST"])
def checkout():
    items = cart_items()
    if not items:
        flash("Your bag is empty. Add a style before checkout.", "info")
        return redirect(url_for("home"))
    total = sum(item["subtotal"] for item in items)
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        phone = request.form.get("phone", "").strip()
        address = request.form.get("address", "").strip()
        if not name or not phone or not address:
            flash("Please complete all delivery details.", "error")
            return render_template("checkout.html", items=items, total=total)
        if not phone.isdigit() or len(phone) != 10:
            flash("Enter a valid 10-digit phone number.", "error")
            return render_template("checkout.html", items=items, total=total)
        session["last_order"] = {
            "order_number": "HS" + datetime.now().strftime("%y%m%d%H%M%S"),
            "name": name, "phone": phone, "address": address,
            "items": items, "total": total
        }
        session["cart"] = {}
        return redirect(url_for("success"))
    return render_template("checkout.html", items=items, total=total)

@app.route("/success")
def success():
    order = session.get("last_order")
    if not order:
        return redirect(url_for("home"))
    return render_template("success.html", order=order)

@app.errorhandler(404)
def page_not_found(error):
    return render_template("not_found.html"), 404

if __name__ == "__main__":
    app.run(debug=True)
